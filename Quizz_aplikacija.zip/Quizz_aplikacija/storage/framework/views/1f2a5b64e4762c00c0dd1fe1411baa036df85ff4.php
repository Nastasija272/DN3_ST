<div class="jumbotron text-center">
    <h1 class="display-3">Thank You!</h1>
  </div>
<?php /**PATH C:\Nastasija\Drugi_Letnik\SEMESTAR_2\ST\DN_3\Quizz_aplikacija\resources\views/ty.blade.php ENDPATH**/ ?>