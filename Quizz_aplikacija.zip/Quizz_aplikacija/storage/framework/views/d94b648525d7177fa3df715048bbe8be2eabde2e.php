<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Nastasija\Drugi_Letnik\SEMESTAR_2\ST\DN_3\Quizz_aplikacija\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>